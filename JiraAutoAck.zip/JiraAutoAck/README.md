# Jira Auto Ack (Android)

A small phone app for the Pixel 8 Pro that acknowledges Jira voice alerts on your own number.
Nothing leaves the phone: no cloud service, no accounts, no internet permission.

## What it does

When the on-shift switch is on and a call arrives from a number starting with `+1`:

| Time after answering | Action |
|---|---|
| 0 s | Answers the call (microphone muted) |
| 5.0 s | Presses 3 |
| 7.3 s | Presses 0 |
| 12.6 s | Hangs up |

Every other call rings normally and is answered by you:

- numbers starting with `+91`
- any other country code
- numbers shown without a country code
- hidden numbers
- any call that arrives while you are already on another call
- every call while the switch is off

## Test status

- The number rule, the key timing and the call handling were tested in a simulation: 22 checks, all passed.
- The project has NOT been built with the real Android SDK and has NOT been run on a phone.
  Expect to fix small issues on the first build, and test with a real Jira alert before relying on it.

## Build and install

1. Install Android Studio on your Mac.
2. File > Open, choose this `JiraAutoAck` folder, and wait for the sync to finish.
3. On the Pixel: Settings > About phone > tap "Build number" 7 times, then
   Settings > System > Developer options > turn on "USB debugging".
4. Connect the Pixel by USB and press Run in Android Studio.

Command line alternative, with the Android SDK installed: `./gradlew installDebug`

## First-time setup on the phone

1. Open "Jira Auto Ack" and allow the permissions it asks for.
2. Tap "Set as default phone app" and choose Jira Auto Ack.
3. If the button "Allow the call screen on the lock screen" is shown, tap it and allow it.

## Each shift

- Start of shift: open the app and turn on "Auto-acknowledge".
- End of shift: turn it off.
- Off shift, switch the default phone app back to Google's Phone app
  (Settings > Apps > Default apps > Phone app) to get its full call screen back.

The activity log on the main screen shows each automatic answer and each key pressed.

## Important to know

- While this is the default phone app it handles ALL your calls. Its call screen is basic:
  answer, decline, hang up, mute, speaker, hold, keypad. Google Phone features such as
  call screening and spam warnings are not available while it is the default.
- Any caller whose number starts with `+1` is auto-answered while the switch is on,
  not only Jira. To limit it to Jira's numbers, put the full numbers in
  `AUTO_ACK_PREFIXES` in `AckConfig.java`, for example `{"+14155551234", "+16505550000"}`.
- Check your call history for how Jira's calls appear. If they are shown without `+1`
  they will ring normally; adjust `AUTO_ACK_PREFIXES` to match.
- Emergency calling with this app as the default phone app has not been tested.
- An auto-acknowledged alert stops escalating in Jira even though nobody has looked at it.

## Changing the behaviour

Everything is in `app/src/main/java/com/sre/jiraautoack/AckConfig.java`:

| Setting | Default | Meaning |
|---|---|---|
| `AUTO_ACK_PREFIXES` | `+1` | Numbers that are auto-acknowledged |
| `NEVER_ACK_PREFIXES` | `+91` | Numbers that are never auto-acknowledged |
| `DIGITS` | `30` | Keys pressed, in order |
| `WAIT_BEFORE_DIGITS_MS` | 5000 | Wait after answering |
| `GAP_BETWEEN_DIGITS_MS` | 2000 | Wait between keys |
| `HOLD_AFTER_DIGITS_MS` | 5000 | Wait before hanging up |

## Files

| File | Purpose |
|---|---|
| `AckConfig.java` | Number rule and timings |
| `CallService.java` | Receives every call; runs the auto-acknowledge sequence |
| `CallActivity.java` | Call screen for normal calls |
| `MainActivity.java` | Status, shift switch, dial pad, activity log |
| `CallText.java`, `CallHolder.java`, `Prefs.java`, `CallActionReceiver.java` | Helpers |
