package com.sre.jiraautoack;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telecom.Call;

import java.util.HashMap;
import java.util.Map;

/** Text shown for a call: who it is and what state it is in. */
final class CallText {

    private static final Map<String, String> NAME_CACHE = new HashMap<>();

    private CallText() {
    }

    static String numberOf(Call call) {
        Call.Details details = call.getDetails();
        Uri handle = details == null ? null : details.getHandle();
        String number = handle == null ? null : handle.getSchemeSpecificPart();
        return number == null ? "" : number;
    }

    static int stateOf(Call call) {
        Call.Details details = call.getDetails();
        return details == null ? Call.STATE_NEW : details.getState();
    }

    static String displayName(Context context, Call call) {
        String number = numberOf(call);
        if (number.isEmpty()) {
            return "Unknown caller";
        }
        String name = contactName(context, number);
        return name == null ? number : name + "\n" + number;
    }

    static String stateLabel(int state) {
        switch (state) {
            case Call.STATE_RINGING:
                return "Incoming call";
            case Call.STATE_DIALING:
            case Call.STATE_CONNECTING:
                return "Calling";
            case Call.STATE_ACTIVE:
                return "Connected";
            case Call.STATE_HOLDING:
                return "On hold";
            case Call.STATE_SELECT_PHONE_ACCOUNT:
                return "Choose a SIM";
            case Call.STATE_DISCONNECTING:
            case Call.STATE_DISCONNECTED:
                return "Call ended";
            default:
                return "Call";
        }
    }

    /** Looks the number up in Contacts. Returns null if not found or not permitted. */
    private static String contactName(Context context, String number) {
        if (NAME_CACHE.containsKey(number)) {
            return NAME_CACHE.get(number);
        }
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            return null;
        }
        String name = null;
        Uri uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
        String[] columns = {ContactsContract.PhoneLookup.DISPLAY_NAME};
        try (Cursor cursor = context.getContentResolver().query(uri, columns, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                name = cursor.getString(0);
            }
        } catch (RuntimeException e) {
            // Contacts not available: fall back to showing the number.
        }
        NAME_CACHE.put(number, name);
        return name;
    }
}
