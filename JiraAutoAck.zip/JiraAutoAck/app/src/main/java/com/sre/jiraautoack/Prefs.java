package com.sre.jiraautoack;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Stores the on-shift switch and a short activity log. */
final class Prefs {

    private static final String FILE = "jira_auto_ack";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_LOG = "log";
    private static final int MAX_LOG_LINES = 50;

    private Prefs() {
    }

    private static SharedPreferences sp(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /** Off by default, so nothing is auto-answered until you switch it on. */
    static boolean isEnabled(Context context) {
        return sp(context).getBoolean(KEY_ENABLED, false);
    }

    static void setEnabled(Context context, boolean enabled) {
        sp(context).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /** Adds a line to the top of the log and keeps the newest 50 lines. */
    static synchronized void log(Context context, String message) {
        Log.i("JiraAutoAck", message);
        String stamp = new SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(new Date());
        String old = sp(context).getString(KEY_LOG, "");
        String[] lines = old.isEmpty() ? new String[0] : old.split("\n");
        StringBuilder sb = new StringBuilder(stamp).append("  ").append(message);
        for (int i = 0; i < lines.length && i < MAX_LOG_LINES - 1; i++) {
            sb.append('\n').append(lines[i]);
        }
        sp(context).edit().putString(KEY_LOG, sb.toString()).apply();
    }

    static String getLog(Context context) {
        return sp(context).getString(KEY_LOG, "");
    }

    static void clearLog(Context context) {
        sp(context).edit().remove(KEY_LOG).apply();
    }
}
