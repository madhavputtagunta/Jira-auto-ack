package com.sre.jiraautoack;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import android.telecom.VideoProfile;

import java.util.HashSet;
import java.util.Set;

/**
 * Android hands every call to this service while this app is the default phone app.
 *
 * Incoming call from a +1 number, with the on-shift switch on:
 *   answer, wait 5 s, press 3, wait 2 s, press 0, wait 5 s, hang up. No screen is shown.
 *
 * Every other call (+91, other countries, hidden numbers, outgoing calls):
 *   rings and behaves normally, using the call screen in CallActivity.
 */
public class CallService extends InCallService {

    private static final String CHANNEL_INCOMING = "incoming_calls";
    private static final String CHANNEL_ONGOING = "ongoing_calls";
    private static final int NOTIFICATION_ID = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());

    /** Calls this service answered by itself. */
    private final Set<Call> autoAckCalls = new HashSet<>();

    /** Auto-answered calls whose key sequence has already been scheduled. */
    private final Set<Call> sequenceStarted = new HashSet<>();

    private String shownChannel;

    private final Call.Callback callCallback = new Call.Callback() {
        @Override
        public void onStateChanged(Call call, int state) {
            if (state == Call.STATE_ACTIVE && autoAckCalls.contains(call)
                    && sequenceStarted.add(call)) {
                startKeySequence(call);
            }
            refresh();
        }

        @Override
        public void onDetailsChanged(Call call, Call.Details details) {
            refresh();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        CallHolder.service = this;
        createChannels();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        CallHolder.service = null;
        CallHolder.primary = null;
        getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
        CallHolder.notifyChanged();
        super.onDestroy();
    }

    @Override
    public void onCallAdded(Call call) {
        super.onCallAdded(call);
        call.registerCallback(callCallback);

        int state = CallText.stateOf(call);
        String number = CallText.numberOf(call);

        if (state == Call.STATE_RINGING && AckConfig.shouldAutoAck(number)) {
            if (!Prefs.isEnabled(this)) {
                Prefs.log(this, "Call from " + number + ": auto-acknowledge is off, ringing normally");
            } else if (getCalls().size() > 1) {
                // Answering would put the call you are already on on hold.
                Prefs.log(this, "Call from " + number + ": another call is in progress, ringing normally");
            } else {
                autoAckCalls.add(call);
                Prefs.log(this, "Call from " + number + ": answering automatically");
                call.answer(VideoProfile.STATE_AUDIO_ONLY);
            }
        } else if (state != Call.STATE_RINGING) {
            // Outgoing call: open the call screen straight away.
            openCallScreen();
        }
        refresh();
    }

    @Override
    public void onCallRemoved(Call call) {
        super.onCallRemoved(call);
        call.unregisterCallback(callCallback);
        handler.removeCallbacksAndMessages(call);
        sequenceStarted.remove(call);
        if (autoAckCalls.remove(call)) {
            setMuted(false);
            Prefs.log(this, "Call from " + CallText.numberOf(call) + " ended");
        }
        refresh();
    }

    @Override
    public void onCallAudioStateChanged(CallAudioState audioState) {
        super.onCallAudioStateChanged(audioState);
        CallHolder.notifyChanged();
    }

    // ---------------------------------------------------------------------
    // Auto-acknowledge
    // ---------------------------------------------------------------------

    /** Called once, when an auto-answered call becomes connected. */
    private void startKeySequence(final Call call) {
        // Keep the room quiet on the line. Key tones are still sent while muted.
        setMuted(true);
        Prefs.log(this, "Connected, waiting " + (AckConfig.WAIT_BEFORE_DIGITS_MS / 1000) + " s");
        for (final AckConfig.Step step : AckConfig.buildSchedule()) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    runStep(call, step);
                }
            }, call, step.atMs);
        }
    }

    private void runStep(Call call, AckConfig.Step step) {
        if (CallText.stateOf(call) != Call.STATE_ACTIVE) {
            return; // The caller hung up first.
        }
        switch (step.type) {
            case AckConfig.STEP_TONE_START:
                call.playDtmfTone(step.digit);
                Prefs.log(this, "Pressed " + step.digit);
                break;
            case AckConfig.STEP_TONE_STOP:
                call.stopDtmfTone();
                break;
            case AckConfig.STEP_HANG_UP:
                Prefs.log(this, "Keys sent, hanging up");
                call.disconnect();
                break;
            default:
                break;
        }
    }

    // ---------------------------------------------------------------------
    // Normal calls: notification and call screen
    // ---------------------------------------------------------------------

    private void refresh() {
        Call primary = pickPrimary();
        CallHolder.primary = primary;
        updateNotification(primary);
        CallHolder.notifyChanged();
    }

    /** A ringing call first, then any other normal call, then an auto-answered call. */
    private Call pickPrimary() {
        Call normal = null;
        Call auto = null;
        for (Call call : getCalls()) {
            int state = CallText.stateOf(call);
            if (state == Call.STATE_DISCONNECTED) {
                continue;
            }
            if (autoAckCalls.contains(call)) {
                auto = call;
            } else if (state == Call.STATE_RINGING) {
                return call;
            } else if (normal == null || state == Call.STATE_ACTIVE) {
                normal = call;
            }
        }
        return normal != null ? normal : auto;
    }

    private void openCallScreen() {
        try {
            startActivity(new Intent(this, CallActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (RuntimeException e) {
            // The notification still gives access to the call screen.
        }
    }

    private void createChannels() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        NotificationChannel incoming = new NotificationChannel(
                CHANNEL_INCOMING, "Incoming calls", NotificationManager.IMPORTANCE_HIGH);
        incoming.setSound(null, null); // Android plays the ringtone itself.
        manager.createNotificationChannel(incoming);
        manager.createNotificationChannel(new NotificationChannel(
                CHANNEL_ONGOING, "Ongoing calls", NotificationManager.IMPORTANCE_LOW));
    }

    private void updateNotification(Call call) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (call == null) {
            manager.cancel(NOTIFICATION_ID);
            shownChannel = null;
            return;
        }

        int state = CallText.stateOf(call);
        boolean auto = autoAckCalls.contains(call);
        boolean ringing = state == Call.STATE_RINGING && !auto;
        String channel = ringing ? CHANNEL_INCOMING : CHANNEL_ONGOING;
        String title = CallText.displayName(this, call).replace('\n', ' ');
        String text = auto ? "Acknowledging Jira call automatically" : CallText.stateLabel(state);

        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags);
        PendingIntent answer = PendingIntent.getActivity(this, 1,
                new Intent(this, CallActivity.class)
                        .setAction(CallActivity.ACTION_ANSWER)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags);
        PendingIntent decline = PendingIntent.getBroadcast(this, 2,
                new Intent(this, CallActionReceiver.class)
                        .setAction(CallActionReceiver.ACTION_DECLINE), flags);
        PendingIntent hangUp = PendingIntent.getBroadcast(this, 3,
                new Intent(this, CallActionReceiver.class)
                        .setAction(CallActionReceiver.ACTION_HANG_UP), flags);

        Notification.Builder builder = new Notification.Builder(this, channel)
                .setSmallIcon(android.R.drawable.stat_sys_phone_call)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open);
        if (ringing) {
            // Shows the call screen over the lock screen, or a banner if the phone is in use.
            builder.setFullScreenIntent(open, true);
            builder.addAction(action("Decline", decline));
            builder.addAction(action("Answer", answer));
        } else {
            builder.addAction(action("Hang up", hangUp));
        }

        if (shownChannel != null && !shownChannel.equals(channel)) {
            manager.cancel(NOTIFICATION_ID);
        }
        shownChannel = channel;
        manager.notify(NOTIFICATION_ID, builder.build());
    }

    private static Notification.Action action(String title, PendingIntent intent) {
        return new Notification.Action.Builder((Icon) null, title, intent).build();
    }
}
