package com.sre.jiraautoack;

import android.telecom.Call;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Shares the current call between the call service and the call screen. */
final class CallHolder {

    interface Listener {
        void onCallChanged();
    }

    /** Set while Android has the call service bound, i.e. while a call exists. */
    static CallService service;

    /** The call the call screen and the notification should show, or null. */
    static Call primary;

    private static final List<Listener> LISTENERS = new CopyOnWriteArrayList<>();

    private CallHolder() {
    }

    static void addListener(Listener listener) {
        if (!LISTENERS.contains(listener)) {
            LISTENERS.add(listener);
        }
    }

    static void removeListener(Listener listener) {
        LISTENERS.remove(listener);
    }

    static void notifyChanged() {
        for (Listener listener : LISTENERS) {
            listener.onCallChanged();
        }
    }
}
