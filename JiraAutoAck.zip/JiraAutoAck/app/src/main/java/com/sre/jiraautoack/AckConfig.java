package com.sre.jiraautoack;

import java.util.ArrayList;
import java.util.List;

/**
 * Rules and timings for the automatic acknowledgement.
 * This is the only file you need to edit to change the behaviour.
 */
public final class AckConfig {

    private AckConfig() {
    }

    /** A call is auto-acknowledged only if the caller's number starts with one of these. */
    public static final String[] AUTO_ACK_PREFIXES = {"+1"};

    /** A call is never auto-acknowledged if the caller's number starts with one of these. */
    public static final String[] NEVER_ACK_PREFIXES = {"+91"};

    /** Keys to press, in order. */
    public static final String DIGITS = "30";

    /** Wait after the call is answered, before the first key. */
    public static final long WAIT_BEFORE_DIGITS_MS = 5000;

    /** How long each key tone is held. */
    public static final long TONE_LENGTH_MS = 300;

    /** Wait between the end of one key and the start of the next. */
    public static final long GAP_BETWEEN_DIGITS_MS = 2000;

    /** Stay on the line after the last key so the confirmation can play, then hang up. */
    public static final long HOLD_AFTER_DIGITS_MS = 5000;

    /** Removes spaces, dashes and brackets, and turns a leading "00" into "+". */
    public static String normalize(String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.replaceAll("[^0-9+]", "");
        if (s.startsWith("00")) {
            s = "+" + s.substring(2);
        }
        return s;
    }

    /**
     * True only for numbers that start with an allowed prefix (+1).
     * +91 numbers, numbers without a country code, and hidden numbers return false.
     */
    public static boolean shouldAutoAck(String rawNumber) {
        String number = normalize(rawNumber);
        if (number.isEmpty()) {
            return false;
        }
        for (String prefix : NEVER_ACK_PREFIXES) {
            if (number.startsWith(prefix)) {
                return false;
            }
        }
        for (String prefix : AUTO_ACK_PREFIXES) {
            if (number.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }

    public static final int STEP_TONE_START = 1;
    public static final int STEP_TONE_STOP = 2;
    public static final int STEP_HANG_UP = 3;

    /** One timed action, measured from the moment the call is answered. */
    public static final class Step {
        public final long atMs;
        public final int type;
        public final char digit;

        Step(long atMs, int type, char digit) {
            this.atMs = atMs;
            this.type = type;
            this.digit = digit;
        }
    }

    /**
     * With the default values this produces:
     * 5.0 s press 3, 5.3 s release, 7.3 s press 0, 7.6 s release, 12.6 s hang up.
     */
    public static List<Step> buildSchedule() {
        List<Step> steps = new ArrayList<>();
        long t = WAIT_BEFORE_DIGITS_MS;
        for (int i = 0; i < DIGITS.length(); i++) {
            char digit = DIGITS.charAt(i);
            if (i > 0) {
                t += GAP_BETWEEN_DIGITS_MS;
            }
            steps.add(new Step(t, STEP_TONE_START, digit));
            t += TONE_LENGTH_MS;
            steps.add(new Step(t, STEP_TONE_STOP, digit));
        }
        steps.add(new Step(t + HOLD_AFTER_DIGITS_MS, STEP_HANG_UP, ' '));
        return steps;
    }
}
