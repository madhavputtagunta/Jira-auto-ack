package com.sre.jiraautoack;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.PhoneAccount;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telecom.VideoProfile;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Call screen for calls that are not auto-acknowledged: answer, decline, hang up,
 * mute, speaker, hold and a keypad. It closes itself when the call ends.
 */
public class CallActivity extends Activity implements CallHolder.Listener {

    static final String ACTION_ANSWER = "com.sre.jiraautoack.ANSWER";

    private static final long KEYPAD_TONE_MS = 250;
    private static final long PROXIMITY_TIMEOUT_MS = 4L * 60 * 60 * 1000;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView nameView;
    private TextView statusView;
    private LinearLayout ringingButtons;
    private LinearLayout activeButtons;
    private GridLayout keypad;
    private Button muteButton;
    private Button speakerButton;
    private Button holdButton;

    private PowerManager.WakeLock proximityLock;
    private AlertDialog accountDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(buildLayout());

        PowerManager power = getSystemService(PowerManager.class);
        if (power != null
                && power.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximityLock = power.newWakeLock(
                    PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "jiraautoack:proximity");
        }
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** The Answer button on the notification opens this screen with ACTION_ANSWER. */
    private void handleIntent(Intent intent) {
        Call call = CallHolder.primary;
        if (intent != null && ACTION_ANSWER.equals(intent.getAction())
                && call != null && CallText.stateOf(call) == Call.STATE_RINGING) {
            call.answer(VideoProfile.STATE_AUDIO_ONLY);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        CallHolder.addListener(this);
        render();
    }

    @Override
    protected void onStop() {
        CallHolder.removeListener(this);
        setProximity(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (accountDialog != null) {
            accountDialog.dismiss();
        }
        super.onDestroy();
    }

    @Override
    public void onCallChanged() {
        render();
    }

    // ---------------------------------------------------------------------
    // Rendering
    // ---------------------------------------------------------------------

    private void render() {
        Call call = CallHolder.primary;
        if (call == null) {
            setProximity(false);
            finishAndRemoveTask();
            return;
        }

        int state = CallText.stateOf(call);
        nameView.setText(CallText.displayName(this, call));
        statusView.setText(CallText.stateLabel(state));

        boolean ringing = state == Call.STATE_RINGING;
        ringingButtons.setVisibility(ringing ? View.VISIBLE : View.GONE);
        activeButtons.setVisibility(ringing ? View.GONE : View.VISIBLE);
        if (ringing) {
            keypad.setVisibility(View.GONE);
        }

        CallService service = CallHolder.service;
        CallAudioState audio = service == null ? null : service.getCallAudioState();
        boolean muted = audio != null && audio.isMuted();
        boolean speaker = audio != null && audio.getRoute() == CallAudioState.ROUTE_SPEAKER;
        muteButton.setText(muted ? "Unmute" : "Mute");
        speakerButton.setText(speaker ? "Speaker off" : "Speaker");

        boolean holding = state == Call.STATE_HOLDING;
        boolean canHold = state == Call.STATE_ACTIVE
                && call.getDetails() != null
                && call.getDetails().can(Call.Details.CAPABILITY_HOLD);
        holdButton.setText(holding ? "Resume" : "Hold");
        holdButton.setEnabled(holding || canHold);

        if (state == Call.STATE_SELECT_PHONE_ACCOUNT) {
            showAccountPicker(call);
        }

        boolean atEar = !speaker && (state == Call.STATE_ACTIVE
                || state == Call.STATE_DIALING || state == Call.STATE_HOLDING);
        setProximity(atEar);
    }

    /** Turns the screen off while the phone is held to the ear. */
    private void setProximity(boolean on) {
        if (proximityLock == null) {
            return;
        }
        if (on && !proximityLock.isHeld()) {
            proximityLock.acquire(PROXIMITY_TIMEOUT_MS);
        } else if (!on && proximityLock.isHeld()) {
            proximityLock.release();
        }
    }

    /** Outgoing call on a phone with two SIMs and no default SIM for calls. */
    private void showAccountPicker(final Call call) {
        if (accountDialog != null && accountDialog.isShowing()) {
            return;
        }
        final TelecomManager telecom = getSystemService(TelecomManager.class);
        final List<PhoneAccountHandle> handles;
        try {
            handles = telecom.getCallCapablePhoneAccounts();
        } catch (SecurityException e) {
            call.disconnect();
            return;
        }
        if (handles == null || handles.isEmpty()) {
            call.disconnect();
            return;
        }
        if (handles.size() == 1) {
            call.phoneAccountSelected(handles.get(0), false);
            return;
        }
        String[] labels = new String[handles.size()];
        for (int i = 0; i < labels.length; i++) {
            PhoneAccount account = telecom.getPhoneAccount(handles.get(i));
            CharSequence label = account == null ? null : account.getLabel();
            labels[i] = label == null ? "SIM " + (i + 1) : label.toString();
        }
        accountDialog = new AlertDialog.Builder(this)
                .setTitle("Call with")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        call.phoneAccountSelected(handles.get(which), false);
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        call.disconnect();
                    }
                })
                .show();
    }

    // ---------------------------------------------------------------------
    // Layout (built in code, so the project has no layout files)
    // ---------------------------------------------------------------------

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(24), dp(64), dp(24), dp(32));

        nameView = new TextView(this);
        nameView.setTextSize(28);
        nameView.setGravity(Gravity.CENTER);
        root.addView(nameView, matchWidth());

        statusView = new TextView(this);
        statusView.setTextSize(16);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, dp(8), 0, 0);
        root.addView(statusView, matchWidth());

        root.addView(new View(this), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        keypad = buildKeypad();
        keypad.setVisibility(View.GONE);
        root.addView(keypad, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Shown while the call is ringing.
        ringingButtons = new LinearLayout(this);
        ringingButtons.setOrientation(LinearLayout.HORIZONTAL);
        ringingButtons.addView(button("Decline", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call call = CallHolder.primary;
                if (call != null) {
                    call.reject(false, null);
                }
            }
        }), weighted());
        ringingButtons.addView(button("Answer", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call call = CallHolder.primary;
                if (call != null) {
                    call.answer(VideoProfile.STATE_AUDIO_ONLY);
                }
            }
        }), weighted());
        root.addView(ringingButtons, matchWidth());

        // Shown once the call is dialling or connected.
        activeButtons = new LinearLayout(this);
        activeButtons.setOrientation(LinearLayout.VERTICAL);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);

        muteButton = button("Mute", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CallService service = CallHolder.service;
                if (service != null && service.getCallAudioState() != null) {
                    service.setMuted(!service.getCallAudioState().isMuted());
                }
            }
        });
        controls.addView(muteButton, weighted());

        speakerButton = button("Speaker", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CallService service = CallHolder.service;
                if (service != null && service.getCallAudioState() != null) {
                    boolean speaker = service.getCallAudioState().getRoute()
                            == CallAudioState.ROUTE_SPEAKER;
                    service.setAudioRoute(speaker
                            ? CallAudioState.ROUTE_WIRED_OR_EARPIECE
                            : CallAudioState.ROUTE_SPEAKER);
                }
            }
        });
        controls.addView(speakerButton, weighted());

        holdButton = button("Hold", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call call = CallHolder.primary;
                if (call == null) {
                    return;
                }
                if (CallText.stateOf(call) == Call.STATE_HOLDING) {
                    call.unhold();
                } else {
                    call.hold();
                }
            }
        });
        controls.addView(holdButton, weighted());

        controls.addView(button("Keypad", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keypad.setVisibility(
                        keypad.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        }), weighted());

        activeButtons.addView(controls, matchWidth());
        activeButtons.addView(button("Hang up", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call call = CallHolder.primary;
                if (call != null) {
                    call.disconnect();
                }
            }
        }), matchWidth());
        root.addView(activeButtons, matchWidth());

        return root;
    }

    private GridLayout buildKeypad() {
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        String keys = "123456789*0#";
        for (int i = 0; i < keys.length(); i++) {
            final char key = keys.charAt(i);
            Button keyButton = button(String.valueOf(key), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pressKey(key);
                }
            });
            keyButton.setTextSize(22);
            keyButton.setMinimumWidth(dp(88));
            grid.addView(keyButton);
        }
        return grid;
    }

    private void pressKey(char key) {
        final Call call = CallHolder.primary;
        if (call == null || CallText.stateOf(call) != Call.STATE_ACTIVE) {
            return;
        }
        call.playDtmfTone(key);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                call.stopDtmfTone();
            }
        }, KEYPAD_TONE_MS);
    }

    private Button button(String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
