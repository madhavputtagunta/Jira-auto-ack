package com.sre.jiraautoack;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.Call;

/** Handles the Decline and Hang up buttons on the call notification. */
public class CallActionReceiver extends BroadcastReceiver {

    static final String ACTION_DECLINE = "com.sre.jiraautoack.DECLINE";
    static final String ACTION_HANG_UP = "com.sre.jiraautoack.HANG_UP";

    @Override
    public void onReceive(Context context, Intent intent) {
        Call call = CallHolder.primary;
        if (call == null || intent == null) {
            return;
        }
        if (ACTION_DECLINE.equals(intent.getAction())) {
            call.reject(false, null);
        } else if (ACTION_HANG_UP.equals(intent.getAction())) {
            call.disconnect();
        }
    }
}
