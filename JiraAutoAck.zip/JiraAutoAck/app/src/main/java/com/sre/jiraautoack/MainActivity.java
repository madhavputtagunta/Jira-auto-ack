package com.sre.jiraautoack;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Main screen: make this the default phone app, switch auto-acknowledge on for a
 * shift, place a call, and read the activity log.
 */
public class MainActivity extends Activity {

    private static final int REQUEST_PERMISSIONS = 1;
    private static final int REQUEST_ROLE = 2;

    private TextView statusView;
    private TextView logView;
    private Button roleButton;
    private Button fullScreenButton;
    private Switch enabledSwitch;
    private EditText numberEdit;

    private final CompoundButton.OnCheckedChangeListener switchListener =
            new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton button, boolean checked) {
                    Prefs.setEnabled(MainActivity.this, checked);
                    Prefs.log(MainActivity.this,
                            checked ? "Auto-acknowledge switched ON" : "Auto-acknowledge switched OFF");
                    refresh();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildLayout());
        requestMissingPermissions();
        fillNumberFrom(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        fillNumberFrom(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    /** Other apps (Contacts, links) send the number to dial as a tel: address. */
    private void fillNumberFrom(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data != null && "tel".equals(data.getScheme())) {
            numberEdit.setText(data.getSchemeSpecificPart());
        }
    }

    private boolean isDefaultPhoneApp() {
        RoleManager roles = getSystemService(RoleManager.class);
        return roles != null && roles.isRoleHeld(RoleManager.ROLE_DIALER);
    }

    private void refresh() {
        boolean isDefault = isDefaultPhoneApp();
        boolean enabled = Prefs.isEnabled(this);

        String status;
        if (!isDefault) {
            status = "NOT ACTIVE. This app is not the default phone app, so it cannot answer calls.";
        } else if (enabled) {
            status = "ACTIVE. Calls from " + join(AckConfig.AUTO_ACK_PREFIXES)
                    + " numbers are answered automatically. All other calls ring normally.";
        } else {
            status = "OFF. Every call rings normally.";
        }
        statusView.setText(status);
        roleButton.setVisibility(isDefault ? View.GONE : View.VISIBLE);

        enabledSwitch.setOnCheckedChangeListener(null);
        enabledSwitch.setChecked(enabled);
        enabledSwitch.setOnCheckedChangeListener(switchListener);

        boolean fullScreenBlocked = false;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager notifications = getSystemService(NotificationManager.class);
            fullScreenBlocked = notifications != null && !notifications.canUseFullScreenIntent();
        }
        fullScreenButton.setVisibility(fullScreenBlocked ? View.VISIBLE : View.GONE);

        String log = Prefs.getLog(this);
        logView.setText(log.isEmpty() ? "No activity yet." : log);
    }

    private void requestDefaultPhoneApp() {
        RoleManager roles = getSystemService(RoleManager.class);
        if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_DIALER)) {
            startActivityForResult(
                    roles.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQUEST_ROLE);
        }
    }

    private void openFullScreenSetting() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            Toast.makeText(this, "Open Settings > Apps > Special app access > Full screen notifications",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void placeCall() {
        String number = numberEdit.getText().toString().trim();
        if (number.isEmpty()) {
            return;
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQUEST_PERMISSIONS);
            return;
        }
        TelecomManager telecom = getSystemService(TelecomManager.class);
        telecom.placeCall(Uri.fromParts("tel", number, null), new Bundle());
    }

    private void requestMissingPermissions() {
        List<String> wanted = new ArrayList<>();
        wanted.add(Manifest.permission.CALL_PHONE);
        wanted.add(Manifest.permission.READ_PHONE_STATE);
        wanted.add(Manifest.permission.READ_CONTACTS);
        if (Build.VERSION.SDK_INT >= 33) {
            wanted.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        List<String> missing = new ArrayList<>();
        for (String permission : wanted) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                missing.add(permission);
            }
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        }
    }

    private static String join(String[] values) {
        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(value);
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // Layout (built in code, so the project has no layout files)
    // ---------------------------------------------------------------------

    private View buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));

        root.addView(heading("Status"));
        statusView = text("");
        root.addView(statusView, matchWidth());

        roleButton = button("Set as default phone app", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestDefaultPhoneApp();
            }
        });
        root.addView(roleButton, matchWidth());

        fullScreenButton = button("Allow the call screen on the lock screen",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openFullScreenSetting();
                    }
                });
        root.addView(fullScreenButton, matchWidth());

        root.addView(heading("Shift"));
        enabledSwitch = new Switch(this);
        enabledSwitch.setText("Auto-acknowledge (switch on for your shift)");
        enabledSwitch.setTextSize(16);
        root.addView(enabledSwitch, matchWidth());
        root.addView(text("Answers numbers starting with " + join(AckConfig.AUTO_ACK_PREFIXES)
                + ", waits " + (AckConfig.WAIT_BEFORE_DIGITS_MS / 1000) + " seconds, presses "
                + join(AckConfig.DIGITS.split("")) + ", then hangs up. Numbers starting with "
                + join(AckConfig.NEVER_ACK_PREFIXES) + " and all others ring normally."),
                matchWidth());

        root.addView(heading("Make a call"));
        numberEdit = new EditText(this);
        numberEdit.setHint("Phone number");
        numberEdit.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(numberEdit, matchWidth());
        root.addView(button("Call", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeCall();
            }
        }), matchWidth());

        root.addView(heading("Activity log"));
        logView = text("");
        logView.setTextIsSelectable(true);
        root.addView(logView, matchWidth());
        root.addView(button("Clear log", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.clearLog(MainActivity.this);
                refresh();
            }
        }), matchWidth());

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    private TextView heading(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(20);
        view.setPadding(0, dp(20), 0, dp(6));
        return view;
    }

    private TextView text(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(15);
        return view;
    }

    private Button button(String value, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setOnClickListener(listener);
        return button;
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
